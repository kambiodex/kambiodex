KAMBIODEX BRAND KIT (version 2.0, October 2026 - new logo)

kambiodex-brand-guidelines.pdf -> usage rules (logo, symbol, colors, typefaces, misuse)
brand-guidelines.html          -> same guide, for the browser

logo/    horizontal logo (4 versions) and symbol (4 versions), SVG and transparent PNG
icons/   favicon, iPhone/Android icons and site.webmanifest
social/  profile picture (400 and 1000 px), X header (1500x500), share image (1200x630)
listing/ icons for CoinGecko, DEX Screener, GeckoTerminal and aggregators

Colors: navy #10233F · ink #0E1A2B · gold #D9B26A · dark gold #8A6417 · ice #F3F5F8 · night #0A111C
Typefaces (free, SIL OFL, Google Fonts): Instrument Sans, Instrument Serif, JetBrains Mono
The SVG files wrap the PNG (no font installation needed); a true vector version needs the logo in high resolution or vector format.
Name: always KAMBIODEX — one word, all capitals. Website: www.kambiodex.com

Icons exist in two styles: silver symbol on navy (default) and navy symbol on light background (files ending in -light).
